<?php

/* @var $this yii\web\View */

$this->title = 'Fuzzy C-Means';
?>
<div class="site-index">



    <div class="body-content">
        <div class="col-lg-12 center">

            <h3 style="text-align: center">
                KLUSTERISASI BIDANG KEAHLIAN MAHASISWA <br>
                MENGGUNAKAN TEKNIK DATA MINING DAN FUZZY C-MEANS<br>
                UNTUK MENDUKUNG RENCANA STRATEGIS PROGRAM STUDI TEKNIK INFORMATIKA
            </h3>
            <br>
            <br>
        </div>
        <div class="jumbotron">
            <div class="col-lg-12 center">
                <img src="img/uin.jpg" height="200" width="200">

            </div>
        </div>

    </div>
</div>