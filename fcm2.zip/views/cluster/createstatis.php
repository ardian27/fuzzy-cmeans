<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Cluster */

?>
<div class="cluster-create">
    <?= $this->render('_formstatis', [
        'model' => $model,
    ]) ?>
</div>
