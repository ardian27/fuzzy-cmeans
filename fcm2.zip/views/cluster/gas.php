<?php

use app\models\Nilai;
use yii\data\ActiveDataProvider;
use yii\grid\GridView;
use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Cluster */

print("<pre>Proses Cluster Fuzzy & C-Means dengan data dan Nilai Bobot awal Statis</pre>");

$nilai = Nilai::find()
    ->select('nim, nilai')
    // ->where(['nim'=>11351105880])
    ->asArray()
    ->all();
?>

<?php
$result = array();
$a = 0;
foreach ($nilai as $element) {
    $result[$element['nim']][] = $element['nilai'];
}
?>

<!-- <label>Jumlah Kluster</label><?= Html::textInput('kluster', $value = "2", $options = ['class' => 'form-control', 'maxlength' => 10, 'style' => 'width:350px']) ?>
<label>Maksimal Iterasi</label><?= Html::textInput('max_iterasi', $value = "10000", $options = ['class' => 'form-control', 'maxlength' => 10, 'style' => 'width:350px']) ?>
<label>Minimal Error</label><?= Html::textInput('min_error', $value = "0.00001", $options = ['class' => 'form-control', 'maxlength' => 10, 'style' => 'width:350px']) ?> -->



<?php

print("<pre><h4>Data Nilai Mahasiswa</h4></pre>");

$dataProvider = new ActiveDataProvider([
    'query' => Nilai::find()->limit(580),
    'pagination' => [
        'pageSize' => 10,
    ],
]);
echo GridView::widget([
    'dataProvider' => $dataProvider,
]);



$size = sizeof($data[0]);

$partisi_u1 = $data[0];
$partisi_u2 = $data[1];
$nilai_p = $data[2];

$partisi_u1_akhir = $partisi_u1[$size - 1];
$partisi_u2_akhir = $partisi_u2[$size - 1];
$nilai_p_akhir = $nilai_p[$size - 1];

$size_akhir = sizeof($partisi_u1[0]);


$datafix = array(
    $partisi_u1, $partisi_u2
);

$a = 1;
foreach ($data as   $value) {
    foreach ($data as   $s) {
    print("<p><pre>Data Iterasi  " . $a . "  ".print_r($s, true)."</pre> ");
     
    }
    $a++;

}

$i = 1;
foreach ($partisi_u1 as   $value) {
    print("<pre>Data Nilai Partisi U Cluster 1 Iterasi Ke " . $i . "</pre> ");
    print("<pre> " . print_r($value, true) . "</pre>");
    $i++;
}

$ii = 1;
foreach ($partisi_u2 as   $value) {
    print("<pre>Data Nilai Partisi U Cluster 2 Iterasi Ke " . $ii . "</pre> ");
    print("<pre> " . print_r($value, true) . "</pre>");
    $ii++;
}

$iii = 1;
foreach ($nilai_p as   $value) {
    print("<pre>Data Nilai (P) Iterasi Ke " . $iii . "</pre> ");
    print("<pre> " . print_r($value, true) . "</pre>");
    $iii++;
}
print("<pre> ======= </pre>");

$iiii = 1;
for ($i = 0; $i < $size_akhir; $i++) {
    // echo $partisi_u1_akhir[$i];
    print("<pre> " . $partisi_u1_akhir[$i] . "</pre>");
}
print("<pre> =====s== </pre>");

$iiii = 1;
for ($i = 0; $i < $size_akhir; $i++) {
    // echo $partisi_u1_akhir[$i];
    print("<pre> " . $partisi_u2_akhir[$i] . "</pre>");
}


// foreach ($partisi_u1 as   $value) {
//     foreach ($value as $key => $show) {
//         // print("<pre>Data Nilai Partisi U Ke   " . $i . "</pre> ");
//         print("<pre> " . print_r($show, true) . "</pre>");

//     $i++;
//     }
// }

// foreach ($nilai as $key=>$element) {
//     $result[$key][] = $element['nilai'];
// }

// echo sizeof($results[0]);
// echo sizeof($data[0]);
// print_r($partisi_u1[2]);

?>
<div class="cluster-create">
    <table style="width: 100%; text-align: center;" border="1">
        <tbody>
            <tr>
                <td colspan="4">Warna Hijau </td>
            </tr>
            <tr>
                <td>Nama</td>
                <td>NIM</td>
                <td>C1</td>
                <td>C2</td>
            </tr>

            <?php
            for ($i = 0; $i < $size_akhir; $i++) {
                // echo $partisi_u1_akhir[$i];
                // print("<pre> " . $partisi_u1_akhir[$i] . "</pre>");



                // $mhs = Mahasiswa::findOne(['nim' => $key]);
                $color1 = $partisi_u1_akhir[$i] > $partisi_u2_akhir[$i] ? 'green'  : 'grey';
                $color2 = $partisi_u1_akhir[$i] < $partisi_u2_akhir[$i] ? 'grey'  : 'green';

                // $data1 = array_push($data1, $nilai[0]);
                // $data2 = array_push($data2, $nilai[1]);

                echo
                    '
                    <tr>
                    <td > </td>
                    <td > </td>
                    <td bgcolor="' . $color1 . '"> ' . $partisi_u1_akhir[$i] . '</td>
                    <td bgcolor="' . $color2 . '"> ' . $partisi_u2_akhir[$i] . '</td>
                       
                       

                        

                        
                    </tr>
                    ';
                ?>
            <?php

            }
            ?>

        </tbody>
    </table>
</div>